import zipfile
import os

def zip_directory(path, zip_filename):
    """Zippa la cartella escludendo i file non necessari per la distribuzione."""
    exclude_dirs = {'__pycache__', 'reports', '.git', 'venv', 'logs'}
    exclude_extensions = {'.db', '.pyc', '.log'}
    
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        # Ottieni il nome della cartella base per arcname
        base_folder = os.path.basename(path)
        
        for root, dirs, files in os.walk(path):
            # Filtra le cartelle da escludere
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            for file in files:
                # Filtra i file con estensioni da escludere
                if any(file.endswith(ext) for ext in exclude_extensions):
                    continue
                
                # Non zippare lo zip stesso
                if file == zip_filename:
                    continue
                    
                file_path = os.path.join(root, file)
                # Crea un percorso relativo all'interno dello zip che preservi la struttura
                rel_path = os.path.relpath(file_path, path)
                arcname = os.path.join(base_folder, rel_path)
                zipf.write(file_path, arcname)
    
    print(f"Archivio creato con successo: {zip_filename}")

if __name__ == "__main__":
    current_dir = os.path.dirname(os.path.abspath(__file__))
    project_dir = current_dir 
    zip_name = "bandi-agent.zip"
    
    zip_directory(project_dir, zip_name)
