@echo off
REM Script per eseguire l'agente bandi-agent con timeout di 180 secondi

REM Imposta la directory di lavoro
cd /d "C:\Users\yassi\OneDrive\Desktop\Salvo\bandi-agent"

REM Esegue l'agente con timeout di 180 secondi
timeout /t 5 /nobreak >nul
python src/agent.py

REM Apri il report nel browser predefinito
start "" "reports/report_bandi.html"

REM Mantieni la finestra aperta per vedere eventuali errori
pause