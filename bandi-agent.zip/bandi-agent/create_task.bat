@echo off
REM Script per creare il task pianificato di Windows per l'agente bandi-agent

schtasks /create /tn "BandiAgent" /tr "C:\Users\yassi\OneDrive\Desktop\Salvo\bandi-agent\run_agent.bat" /sc onlogon /ru currentUser

if %errorlevel% equ 0 (
    echo Task pianificato creato con successo.
) else (
    echo Errore nella creazione del task pianificato.
)

pause