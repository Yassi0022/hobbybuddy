import logging
import os
import webbrowser
from datetime import datetime
from config import LOG_DIR, SOURCES, INPA_API_SOURCES
from database import init_db, cleanup_old_records
from scraper import scrape_static_site, scrape_js_site, scrape_inpa_api
from analyzer import analyze_with_ollama, generate_summary_with_ollama
from reporter import generate_html_report

def setup_logging():
    """Configura il logging su file."""
    if not os.path.exists(LOG_DIR):
        os.makedirs(LOG_DIR)

    log_file = os.path.join(LOG_DIR, f"{datetime.now().strftime('%Y%m%d')}.log")

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler()  # Anche nella console
        ]
    )

def main():
    """Funzione principale dell'agente."""
    setup_logging()
    logging.info("Avvio dell'agente bandi-agent")

    # Inizializza il database
    init_db()

    # Pulizia dei record vecchi
    cleanup_old_records()

    # Lista per accumulare tutti i bandi trovati
    all_bandi = []

    # Fonti che richiedono Playwright (JS rendering)
    js_sources = [
        "https://albopretorio.comune.palermo.it",
        "https://portaleappalti.comune.palermo.it/PortaleAppalti/it/ppgare_bandi_lista.wp",
        "https://www.comune.palermo.it",
        "https://www.inpa.gov.it"
    ]

    # Scaricamento e analisi dei bandi dalle fonti
    for source in SOURCES:
        logging.info(f"Elaborazione della fonte: {source}")

        if source in js_sources:
            bandi = scrape_js_site(source)
        elif source in INPA_API_SOURCES:
            bandi = scrape_inpa_api(source)
        else:
            bandi = scrape_static_site(source)

        all_bandi.extend(bandi)

    # Aggiungi anche le fonti API InPA che potrebbero non essere in SOURCES
    for source in INPA_API_SOURCES:
        if source not in SOURCES:
            logging.info(f"Elaborazione della fonte API: {source}")
            bandi = scrape_inpa_api(source)
            all_bandi.extend(bandi)

    # Rimuovi duplicati mantenendo l'ordine
    seen_urls = set()
    unique_bandi = []
    for bando in all_bandi:
        if bando['url'] not in seen_urls:
            seen_urls.add(bando['url'])
            unique_bandi.append(bando)

    logging.info(f"Trovati {len(unique_bandi)} bandi unici in totale")

    # Analisi dei bandi con Ollama e inserimento nel database
    bandi_inseriti = 0
    for bando in unique_bandi:
        url = bando['url']
        titolo = bando['titolo']
        descrizione = bando['descrizione']
        fonte = bando['fonte']

        # Analisi con Ollama
        categoria, rilevanza = analyze_with_ollama(titolo, descrizione)

        # Generazione del sommario con Ollama
        summary_data = generate_summary_with_ollama(titolo, descrizione)

        # Gestisci il caso in cui summary_data potrebbe essere None o vuoto
        if summary_data and isinstance(summary_data, dict):
            sommario = f"""Cosa offre: {summary_data.get('offerta', 'N/A')}
Requisiti: {summary_data.get('requisiti', 'N/A')}
Dettagli: {summary_data.get('dettagli', 'N/A')}
Motivazione rilevanza: {summary_data.get('rilevanza', 'Non specificato')}"""
        else:
            sommario = "Riassunto non disponibile"

        # Inserimento nel database
        from database import insert_bando
        if insert_bando(
            url=url,
            titolo=titolo,
            descrizione=descrizione,
            data_pubblicazione="",  # Da implementare meglio in futuro
            fonte=fonte,
            categoria=categoria,
            rilevanza=rilevanza,
            sommario=sommario
        ):
            bandi_inseriti += 1

    logging.info(f"Inseriti {bandi_inseriti} nuovi bandi nel database")

    # Generazione del report HTML
    report_path = generate_html_report()
    logging.info(f"Report HTML generato: {report_path}")

    # Apri il report nel browser predefinito
    try:
        webbrowser.open(f"file://{os.path.abspath(report_path)}")
        logging.info("Report aperto nel browser")
    except Exception as e:
        logging.warning(f"Impossibile aprire il report nel browser: {e}")

    logging.info("Agente bandi-agent completato")

if __name__ == "__main__":
    main()