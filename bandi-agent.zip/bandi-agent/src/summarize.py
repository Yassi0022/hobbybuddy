import requests

OLLAMA_URL = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "qwen2.5-coder:latest"

PROMPT_TEMPLATE = """
Sei un assistente specializzato in bandi pubblici italiani.
Analizza questo bando e rispondi in italiano con:
1. Cosa offre in 2 righe
2. Chi può partecipare (requisiti chiave)
3. Perché è rilevante per un laureato in Psicologia del Lavoro e Informatica a Palermo

BANDO:
{testo}

Rispondi in modo conciso e diretto.
"""

def summarize(titolo: str, testo: str) -> str:
    try:
        payload = {
            "model": OLLAMA_MODEL,
            "prompt": PROMPT_TEMPLATE.format(testo=f"{titolo}\n{testo[:1000]}"),
            "stream": False,
            "options": {"temperature": 0.3}
        }
        resp = requests.post(OLLAMA_URL, json=payload, timeout=60)
        if resp.status_code == 200:
            return resp.json().get("response", "Riassunto non disponibile")
        return "Riassunto non disponibile"
    except Exception:
        return "Riassunto non disponibile"