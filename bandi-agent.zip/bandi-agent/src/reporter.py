import sqlite3
import logging
from datetime import datetime
from config import REPORT_PATH, DB_PATH
from database import get_statistics, mark_as_seen

def get_category_color(category):
    """Restituisce il colore associato a una categoria."""
    colors = {
        'Concorso PA': '#28a745',      # verde
        'Psicologia': '#6f42c1',       # viola
        'FSE/PNRR': '#007bff',         # blu
        'Scuola': '#fd7e14',           # arancio
        'Informatica': '#17a2b8',      # ciano
        'HR': '#e83e8c',               # rosa
        'Formazione': '#ffc107',       # giallo
        'Incarichi': '#20c997',        # teal
        'Generico': '#6c757d'          # grigio
    }
    return colors.get(category, '#6c757d')

def generate_stars(rating):
    """Genera stelle HTML per la valutazione (1-5)."""
    rating = max(1, min(5, int(rating)))
    return '⭐' * rating + '☆' * (5 - rating)

def generate_html_report():
    """Genera un report HTML professionale e moderno."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        SELECT url, titolo, descrizione, data_pubblicazione, fonte, categoria, rilevanza, data_aggiunta, sommario, visto
        FROM bandi
        ORDER BY rilevanza DESC, data_aggiunta DESC
    ''')

    bandi = cursor.fetchall()
    conn.close()

    stats = get_statistics()
    high_relevance_count = sum(1 for b in bandi if b[6] >= 4)
    
    # Prepara le categorie per i filtri
    categories = sorted(list(stats['by_category'].keys()))

    html_content = f"""<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BandiRadar Sicilia - {datetime.now().strftime('%d/%m/%Y')}</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --bg-body: #f4f7f6;
            --bg-header: #1a1a2e;
            --bg-card: #ffffff;
            --text-main: #333333;
            --text-muted: #666666;
            --primary: #3498db;
            --accent: #e74c3c;
            --border: #e1e8ed;
            --shadow: 0 4px 20px rgba(0,0,0,0.08);
            --header-gradient: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        }}

        [data-theme="dark"] {{
            --bg-body: #0f0f1a;
            --bg-header: #16213e;
            --bg-card: #1a1a2e;
            --text-main: #e0e0e0;
            --text-muted: #aaaaaa;
            --border: #2a2a4a;
            --shadow: 0 4px 25px rgba(0,0,0,0.3);
        }}

        * {{ box-sizing: border-box; transition: all 0.3s ease; }}

        body {{
            font-family: 'Outfit', sans-serif;
            background-color: var(--bg-body);
            color: var(--text-main);
            margin: 0;
            padding: 0;
            line-height: 1.6;
        }}

        header {{
            background: var(--header-gradient);
            color: white;
            padding: 40px 20px;
            text-align: center;
            position: relative;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }}

        .theme-switch {{
            position: absolute;
            top: 20px;
            right: 20px;
            cursor: pointer;
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,255,255,0.2);
            padding: 8px 15px;
            border-radius: 20px;
            color: white;
            font-size: 0.9rem;
            backdrop-filter: blur(5px);
        }}

        .theme-switch:hover {{ background: rgba(255,255,255,0.2); }}

        .logo {{ font-size: 2.5rem; font-weight: 700; margin-bottom: 5px; letter-spacing: -1px; }}
        .subtitle {{ opacity: 0.8; font-weight: 300; margin-bottom: 30px; }}

        .stats-container {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            max-width: 1000px;
            margin: 0 auto;
        }}

        .stat-card {{
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(10px);
            padding: 20px;
            border-radius: 15px;
            border: 1px solid rgba(255,255,255,0.1);
        }}

        .stat-val {{ font-size: 1.8rem; font-weight: 700; display: block; }}
        .stat-lab {{ font-size: 0.85rem; text-transform: uppercase; opacity: 0.7; }}

        .main-container {{ max-width: 1000px; margin: -30px auto 50px; padding: 0 20px; position: relative; z-index: 10; }}

        .search-filters {{
            background: var(--bg-card);
            padding: 20px;
            border-radius: 15px;
            box-shadow: var(--shadow);
            margin-bottom: 30px;
            display: flex;
            flex-direction: column;
            gap: 20px;
            border: 1px solid var(--border);
        }}

        .search-bar {{
            width: 100%;
            padding: 12px 20px;
            border-radius: 10px;
            border: 1px solid var(--border);
            background: var(--bg-body);
            color: var(--text-main);
            font-size: 1rem;
        }}

        .pill-filters {{ display: flex; flex-wrap: wrap; gap: 10px; }}
        .pill {{
            padding: 8px 16px;
            border-radius: 20px;
            border: 1px solid var(--border);
            background: var(--bg-body);
            color: var(--text-muted);
            cursor: pointer;
            font-size: 0.9rem;
            font-weight: 600;
        }}
        .pill.active {{ background: var(--primary); color: white; border-color: var(--primary); }}

        .relevance-filter {{ display: flex; align-items: center; gap: 15px; color: var(--text-muted); font-size: 0.9rem; }}

        .bando-card {{
            background: var(--bg-card);
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 25px;
            border: 1px solid var(--border);
            border-left: 6px solid #ccc;
            box-shadow: var(--shadow);
            position: relative;
        }}
        .bando-card:hover {{ transform: scale(1.01); box-shadow: 0 8px 30px rgba(0,0,0,0.12); }}

        .card-header {{ display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px; }}
        .bando-title {{ font-size: 1.25rem; font-weight: 700; margin: 0; color: var(--primary); text-decoration: none; display: block; }}
        .bando-title:hover {{ text-decoration: underline; }}

        .badge {{
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            margin-left: 10px;
            color: white;
        }}

        .stars {{ color: #f1c40f; letter-spacing: 2px; }}

        .card-meta {{ font-size: 0.85rem; color: var(--text-muted); margin-bottom: 15px; display: flex; gap: 15px; }}
        .card-desc {{ font-size: 0.95rem; margin-bottom: 20px; }}

        details {{
            background: var(--bg-body);
            padding: 15px;
            border-radius: 10px;
            border: 1px solid var(--border);
        }}
        summary {{ font-weight: 600; cursor: pointer; color: var(--primary); outline: none; }}
        .summary-grid {{ display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-top: 15px; font-size: 0.9rem; }}
        .summary-box {{ padding: 10px; background: var(--bg-card); border-radius: 8px; border: 1px solid var(--border); }}
        .summary-box h4 {{ margin: 0 0 5px 0; font-size: 0.8rem; text-transform: uppercase; color: var(--text-muted); }}

        .new-badge {{
            position: absolute;
            top: -10px;
            left: -10px;
            background: var(--accent);
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.7rem;
            font-weight: 700;
            box-shadow: 2px 2px 5px rgba(0,0,0,0.2);
        }}

        footer {{ text-align: center; padding: 40px; color: var(--text-muted); font-size: 0.85rem; }}

        @media (max-width: 600px) {{
            .summary-grid {{ grid-template-columns: 1fr; }}
            .card-header {{ flex-direction: column; }}
            .pill-filters {{ justify-content: center; }}
        }}
    </style>
</head>
<body data-theme="light">
    <header>
        <button class="theme-switch" onclick="toggleTheme()">🌓 Dark Mode</button>
        <div class="logo">🔍 BandiRadar Sicilia</div>
        <div class="subtitle">Ricerca intelligente opportunità • Aggiornato: {datetime.now().strftime('%d/%m/%Y %H:%M')}</div>
        
        <div class="stats-container">
            <div class="stat-card">
                <span class="stat-val">{stats['total']}</span>
                <span class="stat-lab">Totale Bandi</span>
            </div>
            <div class="stat-card">
                <span class="stat-val">{stats['new']}</span>
                <span class="stat-lab">Nuovi Oggi</span>
            </div>
            <div class="stat-card">
                <span class="stat-val">{high_relevance_count}</span>
                <span class="stat-lab">Alta Rilevanza</span>
            </div>
            <div class="stat-card">
                <span class="stat-val">{len(categories)}</span>
                <span class="stat-lab">Categorie</span>
            </div>
        </div>
    </header>

    <div class="main-container">
        <div class="search-filters">
            <input type="text" class="search-bar" id="searchInput" placeholder="Cerca bandi per titolo o descrizione..." onkeyup="filterBandi()">
            <div class="pill-filters">
                <div class="pill active" onclick="setCategory(this, 'all')">Tutti</div>
                {"".join([f'<div class="pill" onclick="setCategory(this, \'{c}\')">{c}</div>' for c in categories])}
            </div>
            <div class="relevance-filter">
                Minima Rilevanza: 
                <select id="relevanceFilter" onchange="filterBandi()" style="padding: 5px; border-radius: 5px; border: 1px solid var(--border); background: var(--bg-body); color: var(--text-main);">
                    <option value="1">1 stella</option>
                    <option value="2">2 stelle</option>
                    <option value="3">3 stelle</option>
                    <option value="4">4 stelle</option>
                    <option value="5">5 stelle</option>
                </select>
            </div>
        </div>

        <div id="results">
"""

    oggi = datetime.now().date()

    for bando in bandi:
        url, titolo, descrizione, data_pub, fonte, categoria, rilevanza, data_agg, sommario, visto = bando
        
        try:
            data_agg_date = datetime.strptime(data_agg.split()[0], '%Y-%m-%d').date()
            is_new = (data_agg_date == oggi) and not visto
        except:
            is_new = False

        color = get_category_color(categoria)
        stars_html = generate_stars(rilevanza)
        
        # Estrai sommario JSON se possibile
        summ = {"offerta": "N/D", "requisiti": "N/D", "dettagli": "N/D", "rilevanza": "N/D"}
        if sommario and sommario.startswith("{"):
            import json
            try: summ = json.loads(sommario)
            except: pass
        elif sommario and "Cosa offre:" in sommario:
            # Fallback per vecchio formato
            lines = sommario.split('\n')
            for line in lines:
                if "Cosa offre:" in line: summ["offerta"] = line.replace("Cosa offre:", "").strip()
                if "Requisiti:" in line: summ["requisiti"] = line.replace("Requisiti:", "").strip()
                if "Dettagli:" in line: summ["dettagli"] = line.replace("Dettagli:", "").strip()
                if "Motivazione rilevanza:" in line: summ["rilevanza"] = line.replace("Motivazione rilevanza:", "").strip()

        html_content += f"""
            <div class="bando-card" data-cat="{categoria}" data-rating="{rilevanza}" style="border-left-color: {color}">
                { '<div class="new-badge">NUOVO Сегодня</div>' if is_new else '' }
                <div class="card-header">
                    <a href="{url}" class="bando-title" target="_blank">{titolo}</a>
                    <div style="text-align: right">
                        <span class="stars">{stars_html}</span>
                        <div class="badge" style="background: {color}">{categoria}</div>
                    </div>
                </div>
                <div class="card-meta">
                    <span>📍 {fonte[:50]}{'...' if len(fonte)>50 else ''}</span>
                    <span>🕒 {data_agg.split()[0] if data_agg else 'Oggi'}</span>
                </div>
                <div class="card-desc">
                    {descrizione[:300] if descrizione else 'Nessuna descrizione estratta.'}...
                </div>
                <details>
                    <summary>🤖 Analisi AI Avanzata</summary>
                    <div class="summary-grid">
                        <div class="summary-box">
                            <h4>💼 Cosa offre</h4>
                            {summ.get('offerta', 'N/D')}
                        </div>
                        <div class="summary-box">
                            <h4>📋 Requisiti</h4>
                            {summ.get('requisiti', 'N/D')}
                        </div>
                        <div class="summary-box">
                            <h4>📅 Dettagli</h4>
                            {summ.get('dettagli', 'N/D')}
                        </div>
                        <div class="summary-box">
                            <h4>🎯 Perché rilevante</h4>
                            {summ.get('rilevanza', 'N/D')}
                        </div>
                    </div>
                </details>
            </div>
"""

    html_content += """
        </div>
    </div>

    <footer>
        BandiRadar Sicilia • Sviluppato per automazione professionale • Profilo: Psicologo / IT Palermo
    </footer>

    <script>
        let currentCategory = 'all';

        function toggleTheme() {
            const body = document.body;
            const current = body.getAttribute('data-theme');
            const target = current === 'light' ? 'dark' : 'light';
            body.setAttribute('data-theme', target);
            document.querySelector('.theme-switch').textContent = target === 'light' ? '🌓 Dark Mode' : '☀️ Light Mode';
        }

        function setCategory(el, cat) {
            document.querySelectorAll('.pill').forEach(p => p.classList.remove('active'));
            el.classList.add('active');
            currentCategory = cat;
            filterBandi();
        }

        function filterBandi() {
            const search = document.getElementById('searchInput').value.toLowerCase();
            const minRating = document.getElementById('relevanceFilter').value;
            const cards = document.querySelectorAll('.bando-card');

            cards.forEach(card => {
                const title = card.querySelector('.bando-title').innerText.toLowerCase();
                const desc = card.querySelector('.card-desc').innerText.toLowerCase();
                const cat = card.getAttribute('data-cat');
                const rating = parseInt(card.getAttribute('data-rating'));

                const matchesSearch = title.includes(search) || desc.includes(search);
                const matchesCat = currentCategory === 'all' || cat === currentCategory;
                const matchesRating = rating >= minRating;

                if (matchesSearch && matchesCat && matchesRating) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        }
    </script>
</body>
</html>
"""

    with open(REPORT_PATH, 'w', encoding='utf-8') as f:
        f.write(html_content)

    mark_as_seen()
    logging.info(f"Report BandiRadar Sicilia generato: {REPORT_PATH}")
    return REPORT_PATH