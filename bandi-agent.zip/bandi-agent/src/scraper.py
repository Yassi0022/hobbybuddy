import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import logging
from config import SOURCES, FILTER_KEYWORDS
from playwright.sync_api import sync_playwright
import time

def extract_bando_content(url):
    """Scarica il contenuto della pagina del bando per estrarre la descrizione reale."""
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # Cerca testo in tag significativi
        content_tags = soup.find_all(['p', 'article', 'main'])
        text = " ".join([tag.get_text().strip() for tag in content_tags])
        
        # Pulisci il testo
        import re
        text = re.sub(r'\s+', ' ', text).strip()
        
        # Restituisci i primi 1000 caratteri
        return text[:1000] if text else ""
    except Exception as e:
        logging.warning(f"Impossibile estrarre contenuto da {url}: {str(e)}")
        return ""

def is_relevant(text, title=""):
    """Controlla se il testo contiene parole chiave rilevanti e non contiene filtri indesiderati."""
    text_lower = text.lower()
    title_lower = title.lower().strip()

    # --- FILTRI RICHIESTI ---
    # 1. Escludi bandi con titolo vuoto
    if not title_lower:
        return False
    
    # 2. Escludi bandi con titolo < 15 caratteri
    if len(title_lower) < 15:
        return False

    # 3. Escludi bandi che contengono parole specifiche
    excluded_keywords = [
        "twitter", "facebook", "instagram", "homepage", 
        "vai al sito", "torna", "menu", "cerca", "cookie", "privacy", "accedi", "login"
    ]
    for ex_key in excluded_keywords:
        if ex_key in title_lower or ex_key in text_lower:
            return False
    # ------------------------------

    # Controlla se contiene filtri indesiderati esistenti
    for keyword in FILTER_KEYWORDS:
        if keyword in text_lower:
            return False

    # Definisci parole chiave rilevanti per l'utente (da config o fisse)
    relevant_keywords = [
        "psicologia", "informatica", "ingegneria", "lavoro", "formazione",
        "docenza", "scuola", "hr", "it", "concorso", "selezione", "bando",
        "fse", "pnrr", "formatori", "personale", "tutoraggio", "orientamento",
        "benessere organizzativo", "selezione", "incarico", "opportunità"
    ]

    # Controlla se contiene almeno una parola chiave rilevante
    return any(keyword in text_lower for keyword in relevant_keywords)

def scrape_static_site(url):
    """Scarica e analizza un sito statico."""
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()

        soup = BeautifulSoup(response.content, 'html.parser')

        # Estrai i link ai bandi
        links = []
        for link in soup.find_all('a', href=True):
            href = link['href']
            full_url = urljoin(url, href)

            # Controlla se il link è rilevante
            link_text = link.get_text() + " " + link.get('title', '')
            titolo_attuale = link.get_text().strip()
            if is_relevant(link_text, title=titolo_attuale):
                # FIX 1: Estrai il contenuto reale del bando
                logging.info(f"Approfondimento bando: {titolo_attuale}")
                descrizione_reale = extract_bando_content(full_url)
                
                links.append({
                    'url': full_url,
                    'titolo': titolo_attuale,
                    'fonte': url,
                    'descrizione': descrizione_reale if descrizione_reale else (link.get('title', '').strip() or titolo_attuale)
                })

        logging.info(f"Trovati {len(links)} link rilevanti su {url}")
        return links
    except Exception as e:
        logging.error(f"Errore durante lo scraping di {url}: {str(e)}")
        return []

def scrape_js_site(url):
    """Scarica e analizza un sito che richiede JavaScript usando Playwright."""
    logging.info(f"Inizio scraping JS per {url}")

    try:
        with sync_playwright() as p:
            # Avvia il browser Chromium
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()

            # Imposta un timeout ragionevole
            page.set_default_timeout(30000)

            # Vai alla pagina
            page.goto(url)

            # Attendi che la pagina sia caricata
            page.wait_for_load_state("networkidle")

            # Estrai i link ai bandi
            links = []

            # Selettori comuni per trovare link a bandi
            selectors = [
                'a[href*="bando"]',
                'a[href*="concorso"]',
                'a[href*="selezione"]',
                'a[href*="avviso"]',
                'a[href*="opportunità"]',
                'a[title*="bando" i]',
                'a[title*="concorso" i]',
                'a[title*="selezione" i]',
                'a:has-text("bando" i)',
                'a:has-text("concorso" i)',
                'a:has-text("selezione" i)'
            ]

            # Prova diversi selettori
            for selector in selectors:
                try:
                    elements = page.query_selector_all(selector)
                    for element in elements:
                        href = element.get_attribute('href')
                        if href:
                            # Converti URL relativi in assoluti
                            full_url = urljoin(url, href)

                            # Ottieni il testo dell'elemento
                            text = element.text_content().strip()
                            title_attr = element.get_attribute('title') or ''

                            # Controlla se è rilevante
                            combined_text = text + " " + title_attr
                            if is_relevant(combined_text, title=text) and full_url not in [link['url'] for link in links]:
                                # FIX 1: Estrai il contenuto reale del bando
                                logging.info(f"Approfondimento bando JS: {text}")
                                descrizione_reale = extract_bando_content(full_url)
                                
                                links.append({
                                    'url': full_url,
                                    'titolo': text or title_attr or 'Bando senza titolo',
                                    'fonte': url,
                                    'descrizione': descrizione_reale if descrizione_reale else (title_attr or text or '')
                                })
                except Exception as e:
                    logging.debug(f"Selettore {selector} non applicabile per {url}: {str(e)}")
                    continue

            # Se non abbiamo trovato nulla con selettori specifici, cerca tutti i link
            if not links:
                all_links = page.query_selector_all('a[href]')
                for element in all_links:
                    href = element.get_attribute('href')
                    if href:
                        full_url = urljoin(url, href)
                        text = element.text_content().strip()
                        title_attr = element.get_attribute('title') or ''

                        combined_text = text + " " + title_attr
                        if is_relevant(combined_text, title=text) and full_url not in [link['url'] for link in links]:
                            # FIX 1: Estrai il contenuto reale del bando
                            logging.info(f"Approfondimento bando JS (backup): {text}")
                            descrizione_reale = extract_bando_content(full_url)
                            
                            links.append({
                                'url': full_url,
                                'titolo': text or title_attr or 'Bando senza titolo',
                                'fonte': url,
                                'descrizione': descrizione_reale if descrizione_reale else (title_attr or text or '')
                            })

            browser.close()
            logging.info(f"Trovati {len(links)} link rilevanti su {url} con Playwright")
            return links

    except Exception as e:
        logging.error(f"Errore durante lo scraping JS di {url}: {str(e)}")
        return []

def scrape_inpa_api(url):
    """Scarica e analizza le API di InPA."""
    try:
        response = requests.get(url, timeout=15)
        response.raise_for_status()

        data = response.json()
        links = []

        # Gestisci diversi formati di risposta API
        if isinstance(data, list):
            items = data
        elif isinstance(data, dict) and 'items' in data:
            items = data['items']
        elif isinstance(data, dict) and 'posts' in data:
            items = data['posts']
        else:
            items = []

        for item in items:
            # Estrai informazioni dall'item
            url = item.get('link') or item.get('url') or ''
            title = item.get('title') or item.get('post_title') or 'Bando senza titolo'
            description = item.get('excerpt') or item.get('content') or item.get('description') or ''

            if url and is_relevant(title + " " + description, title=title):
                # FIX 1: Estrai il contenuto reale del bando
                logging.info(f"Approfondimento bando API: {title}")
                descrizione_reale = extract_bando_content(url)
                
                links.append({
                    'url': url,
                    'titolo': title,
                    'fonte': url,
                    'descrizione': descrizione_reale if descrizione_reale else (description or title)
                })

        logging.info(f"Trovati {len(links)} bandi dalle API InPA")
        return links

    except Exception as e:
        logging.error(f"Errore durante lo scraping API di {url}: {str(e)}")
        return []