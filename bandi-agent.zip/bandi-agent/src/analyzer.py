import requests
import json
import logging
from config import OLLAMA_URL, OLLAMA_MODEL, PROFILO_UTENTE

def analyze_with_ollama(title, description):
    """
    Analizza il titolo e la descrizione di un bando usando Ollama.
    Restituisce la categoria e la rilevanza (da 1 a 5).
    """
    prompt = f"""
    Analizza il seguente bando per conto di un utente con questo profilo:
    {PROFILO_UTENTE}

    Dati del bando:
    Titolo: {title}
    Descrizione: {description[:1000]}

    Fornisci:
    1. La categoria principale tra queste opzioni:
       - "Concorso PA" (concorsi pubblici, selezioni statali)
       - "Psicologia" (bandi psicologi, orientamento, benessere organizzativo)
       - "FSE/PNRR" (fondi europei, formazione finanziata)
       - "Scuola" (docenza, insegnamento, tutoraggio)
       - "Informatica" (IT, sviluppo software, sistemisti)
       - "HR" (risorse umane, selezioni, reclutamento)
       - "Formazione" (corsi, workshop, seminari)
       - "Incarichi" (lavori autonomi, consulenze, progetti)
       - "Generico" (altro tipo di bando)
    2. Una valutazione di rilevanza da 1 a 5 (dove 1 è poco rilevante e 5 è molto rilevante) basata sul profilo utente.
       Escludere: appalti, lavori fisici, edilizia, strade, forniture.

    Rispondi solo con un JSON nel formato:
    {{
        "categoria": "categoria_identificata",
        "rilevanza": numero_da_1_a_5
    }}
    """

    try:
        response = requests.post(
            OLLAMA_URL,
            json={
                "model": OLLAMA_MODEL,
                "prompt": prompt,
                "stream": False
            },
            timeout=45 # Aumentato timeout per testi più lunghi
        )

        response.raise_for_status()
        result = response.json()

        # Parsing della risposta JSON
        try:
            response_text = result.get('response', str(result))

            # Estrai JSON anche se è avvolto in ```json ... ``` o se c'è testo prima/dopo
            if '```' in response_text:
                parts = response_text.split('```')
                for part in parts:
                    part = part.strip()
                    if part.startswith('json'):
                        part = part[4:].strip()
                    if part.startswith('{'):
                        response_text = part
                        break
            
            # Pulisci ulteriormente se c'è qualcosa fuori dalle graffe
            start_idx = response_text.find('{')
            end_idx = response_text.rfind('}')
            if start_idx != -1 and end_idx != -1:
                response_text = response_text[start_idx:end_idx+1]

            analysis = json.loads(response_text.strip())
            categoria = analysis.get('categoria', 'Generico')
            rilevanza = analysis.get('rilevanza', 1)

            # Assicurati che la rilevanza sia tra 1 e 5
            rilevanza = max(1, min(5, int(rilevanza)))

            return categoria, rilevanza
        except (json.JSONDecodeError, ValueError, TypeError) as e:
            logging.warning(f"Risposta non valida da Ollama per '{title}': {result}")
            return 'Generico', 1

    except requests.exceptions.ConnectionError:
        logging.warning(f"Ollama non disponibile per '{title}', uso categoria predefinita")
        return 'Generico', 1
    except Exception as e:
        logging.error(f"Errore nell'analisi con Ollama per '{title}': {str(e)}")
        return 'Generico', 1

def generate_summary_with_ollama(title, description):
    """
    Genera un sommario AI per il bando usando Ollama.
    Restituisce un dizionario con i dettagli del sommario.
    """
    prompt = f"""
    Per il seguente bando, genera un sommario professionale basato su questo profilo utente:
    {PROFILO_UTENTE}

    Dati del bando:
    Titolo: {title}
    Descrizione: {description[:1000]}

    Genera un sommario in italiano con queste informazioni:
    1. Cosa offre il bando in 2 righe
    2. Chi può partecipare (requisiti chiave)
    3. Scadenza e importo/stipendio se presenti
    4. Perché è rilevante per il profilo specificato

    Rispondi solo con un JSON nel formato:
    {{
        "offerta": "cosa_offre_il_bando_in_2_righe",
        "requisiti": "chi_può_partecipare",
        "dettagli": "scadenza_e_importo_se_presenti",
        "rilevanza": "motivazione_per_la_rilevanza_per_il_profilo"
    }}
    """

    try:
        response = requests.post(
            OLLAMA_URL,
            json={
                "model": OLLAMA_MODEL,
                "prompt": prompt,
                "stream": False
            },
            timeout=45 # Aumentato timeout
        )

        response.raise_for_status()
        result = response.json()

        # Parsing della risposta JSON
        try:
            response_text = result.get('response', str(result))
            
            if '```' in response_text:
                parts = response_text.split('```')
                for part in parts:
                    part = part.strip()
                    if part.startswith('json'):
                        part = part[4:].strip()
                    if part.startswith('{'):
                        response_text = part
                        break
            
            # Pulisci ulteriormente se c'è qualcosa fuori dalle graffe
            start_idx = response_text.find('{')
            end_idx = response_text.rfind('}')
            if start_idx != -1 and end_idx != -1:
                response_text = response_text[start_idx:end_idx+1]

            summary = json.loads(response_text.strip())
            return summary
        except (json.JSONDecodeError, ValueError, TypeError) as e:
            logging.warning(f"Risposta non valida da Ollama per il sommario di '{title}': {result}")
            return {
                "offerta": "Informazioni non disponibili",
                "requisiti": "Informazioni non disponibili",
                "dettagli": "Informazioni non disponibili",
                "rilevanza": "Non specificato"
            }

    except requests.exceptions.ConnectionError:
        logging.warning(f"Ollama non disponibile per il sommario di '{title}'")
        return {
            "offerta": "Riassunto non disponibile (Ollama non disponibile)",
            "requisiti": "Riassunto non disponibile (Ollama non disponibile)",
            "dettagli": "Riassunto non disponibile (Ollama non disponibile)",
            "rilevanza": "Servizio AI non disponibile"
        }
    except Exception as e:
        logging.error(f"Errore nella generazione del sommario con Ollama per '{title}': {str(e)}")
        return {
            "offerta": "Errore nella generazione del sommario",
            "requisiti": "Errore nella generazione del sommario",
            "dettagli": "Errore nella generazione del sommario",
            "rilevanza": "Errore nel calcolo della rilevanza"
        }