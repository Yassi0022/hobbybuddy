import sqlite3
import hashlib
import logging
from datetime import datetime, timedelta
from config import DB_PATH, TTL_DAYS

def init_db():
    """Inizializza il database SQLite e crea la tabella se non esiste."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS bandi (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            url TEXT UNIQUE,
            titolo TEXT,
            descrizione TEXT,
            data_pubblicazione TEXT,
            fonte TEXT,
            categoria TEXT,
            rilevanza INTEGER,
            data_aggiunta TEXT,
            md5_hash TEXT UNIQUE,
            sommario TEXT,
            visto INTEGER DEFAULT 0,
            ente TEXT,
            data_scadenza TEXT,
            requisiti TEXT,
            testo_raw TEXT
        )
    ''')

    # Aggiungi le colonne mancanti se non esistono già
    columns_to_add = [
        ('sommario', 'TEXT'),
        ('visto', 'INTEGER DEFAULT 0'),
        ('ente', 'TEXT'),
        ('data_scadenza', 'TEXT'),
        ('requisiti', 'TEXT'),
        ('testo_raw', 'TEXT')
    ]

    for column_name, column_type in columns_to_add:
        try:
            cursor.execute(f'ALTER TABLE bandi ADD COLUMN {column_name} {column_type}')
        except sqlite3.OperationalError:
            # La colonna esiste già
            pass

    conn.commit()
    conn.close()
    logging.info("Database inizializzato.")

def insert_bando(url, titolo, descrizione, data_pubblicazione, fonte, categoria, rilevanza, sommario=""):
    """Inserisce un nuovo bando nel database."""
    md5_hash = hashlib.md5(url.encode()).hexdigest()
    data_aggiunta = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    try:
        cursor.execute('''
            INSERT INTO bandi (url, titolo, descrizione, data_pubblicazione, fonte, categoria, rilevanza, data_aggiunta, md5_hash, sommario, visto)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (url, titolo, descrizione, data_pubblicazione, fonte, categoria, rilevanza, data_aggiunta, md5_hash, sommario, 0))

        conn.commit()
        logging.info(f"Bando inserito: {titolo}")
        return True
    except sqlite3.IntegrityError:
        logging.warning(f"Bando già presente nel database: {url}")
        return False
    finally:
        conn.close()

def cleanup_old_records():
    """Elimina i record più vecchi di TTL_DAYS giorni."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cutoff_date = (datetime.now() - timedelta(days=TTL_DAYS)).strftime('%Y-%m-%d %H:%M:%S')
    cursor.execute('DELETE FROM bandi WHERE data_aggiunta < ?', (cutoff_date,))

    deleted_count = cursor.rowcount
    conn.commit()
    conn.close()

    logging.info(f"Eliminati {deleted_count} record più vecchi di {TTL_DAYS} giorni.")

def mark_as_seen():
    """Segna tutti i bandi come visti dopo aver aperto il report."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('UPDATE bandi SET visto = 1 WHERE visto = 0')

    updated_count = cursor.rowcount
    conn.commit()
    conn.close()

    logging.info(f"Segnati {updated_count} bandi come visti.")
    return updated_count

def get_statistics():
    """Restituisce statistiche sui bandi nel database."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Totale bandi
    cursor.execute('SELECT COUNT(*) FROM bandi')
    total = cursor.fetchone()[0]

    # Bandi nuovi (non visti)
    cursor.execute('SELECT COUNT(*) FROM bandi WHERE visto = 0')
    new_count = cursor.fetchone()[0]

    # Bandi per categoria
    cursor.execute('SELECT categoria, COUNT(*) FROM bandi GROUP BY categoria')
    by_category = cursor.fetchall()

    conn.close()

    return {
        'total': total,
        'new': new_count,
        'by_category': dict(by_category)
    }