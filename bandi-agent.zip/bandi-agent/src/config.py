import os
from datetime import timedelta

# Configurazioni generali
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, 'db', 'bandi.db')
LOG_DIR = os.path.join(BASE_DIR, 'logs')
REPORT_PATH = os.path.join(BASE_DIR, 'reports', 'report_bandi.html')

# Configurazione Ollama
OLLAMA_URL = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "qwen2.5-coder:latest"

# Profilo Utente (per analisi rilevanza AI)
PROFILO_UTENTE = "Psicologo del Lavoro e Ingegnere Informatico residente a Palermo. Interessi: concorsi PA, bandi FSE/PNRR, formatori, docenza, scuola, HR, IT, psicologia organizzativa, orientamento, benessere organizzativo."

# Fonti dei dati
SOURCES = [
    # Fonti STATICHE (requests + BeautifulSoup)
    "https://www.concorsosicilia.it",
    "https://www.oprs.it/l-ordine-segnala/",
    "https://www.sicilia-fse.it/avvisi-e-bandi",
    "https://cittametropolitana.pa.it/trasparenza/albo-online/",
    "https://www.regione.sicilia.it/alboonline",
    "https://www.concorsando.it/blog/concorsi-palermo/",
    "https://asppalermo.org/trasparenza/bandi-di-concorso/",
    "https://sicilia.istruzione.it",
    "https://repository.comune.palermo.it/amministrazione-trasparente.php?grp=3&lev=2&id=5",

    # Fonti JS (Playwright obbligatorio)
    "https://albopretorio.comune.palermo.it",
    "https://portaleappalti.comune.palermo.it/PortaleAppalti/it/ppgare_bandi_lista.wp",
    "https://www.comune.palermo.it",
    "https://www.inpa.gov.it"
]

# API NASCOSTE InPA
INPA_API_SOURCES = [
    "https://api.inpa.gov.it/job-posts?regione=SICILIA&size=100",
    "https://api.inpa.gov.it/job-posts?size=100",
    "https://www.inpa.gov.it/wp-json/wp/v2/posts?per_page=100"
]

# Filtri per contenuti indesiderati
FILTER_KEYWORDS = [
    "appalti",
    "lavori fisici",
    "edilizia",
    "strade",
    "forniture",
    "manutenzione",
    "cantieri",
    "costruzioni"
]

# Configurazione TTL per i record nel database (3 giorni)
TTL_DAYS = 3
CLEANUP_INTERVAL = timedelta(days=1)