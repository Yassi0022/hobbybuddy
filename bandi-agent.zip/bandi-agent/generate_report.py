import sqlite3
import os
from datetime import datetime

# Configurazione dei percorsi
DB_PATH = os.path.join('db', 'bandi.db')
REPORT_PATH = os.path.join('reports', 'report_bandi.html')

def generate_html_report():
    """Genera un report HTML con i bandi trovati."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Seleziona i bandi ordinati per rilevanza (5 a 1) e data di aggiunta
    cursor.execute('''
        SELECT url, titolo, descrizione, data_pubblicazione, fonte, categoria, rilevanza, data_aggiunta
        FROM bandi
        ORDER BY rilevanza DESC, data_aggiunta DESC
    ''')

    bandi = cursor.fetchall()
    conn.close()

    # Genera l'HTML del report
    html_content = f"""
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Bandi - {datetime.now().strftime('%d/%m/%Y')}</title>
    <style>
        body {{
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
        }}
        h1 {{
            color: #333;
            text-align: center;
        }}
        .bando {{
            background-color: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        .bando-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }}
        .bando-title {{
            font-size: 1.2em;
            font-weight: bold;
            color: #2c3e50;
        }}
        .bando-meta {{
            font-size: 0.9em;
            color: #7f8c8d;
        }}
        .bando-description {{
            margin: 10px 0;
        }}
        .badge {{
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.8em;
            font-weight: bold;
        }}
        .badge-categoria {{
            background-color: #3498db;
            color: white;
        }}
        .badge-rilevanza {{
            background-color: #f39c12;
            color: white;
        }}
        .new-icon {{
            color: #e74c3c;
            font-size: 1.2em;
        }}
    </style>
</head>
<body>
    <h1>_BANDI RILEVANTI PER LA TUA RICERCA</h1>
    <p><em>Aggiornato al: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}</em></p>

"""

    oggi = datetime.now().date()

    for bando in bandi:
        url, titolo, descrizione, data_pub, fonte, categoria, rilevanza, data_agg = bando

        # Determina se è un nuovo bando (aggiunto oggi)
        data_agg_date = datetime.strptime(data_agg.split()[0], '%Y-%m-%d').date()
        is_new = data_agg_date == oggi

        html_content += f"""
    <div class="bando">
        <div class="bando-header">
            <div class="bando-title">
                {'🆕 ' if is_new else ''}<a href="{url}" target="_blank">{titolo}</a>
            </div>
            <div>
                <span class="badge badge-categoria">{categoria}</span>
                <span class="badge badge-rilevanza">Rilevanza: {rilevanza}/5</span>
            </div>
        </div>
        <div class="bando-meta">
            Fonte: {fonte} | Data pubblicazione: {data_pub}
        </div>
        <div class="bando-description">
            {descrizione}
        </div>
    </div>
"""

    html_content += """
</body>
</html>
"""

    # Scrivi il file HTML
    with open(REPORT_PATH, 'w', encoding='utf-8') as f:
        f.write(html_content)

    print(f"Report HTML generato: {REPORT_PATH}")

if __name__ == "__main__":
    generate_html_report()