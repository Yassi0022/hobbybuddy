@echo off
setlocal enabledelayedexpansion

echo ################################################
echo #   BandiRadar Sicilia - INSTALLAZIONE       #
echo ################################################
echo.

REM 1. Controllo versione Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERRORE] Python non trovato. Installalo da https://www.python.org/
    pause
    exit /b 1
)

for /f "tokens=2" %%v in ('python --version') do set pyver=%%v
for /f "tokens=1,2 delims=." %%a in ("%pyver%") do (
    set major=%%a
    set minor=%%b
)

if %major% LSS 3 (
    echo [ERRORE] Richiesto Python 3.10 o superiore. Trovata versione %pyver%
    pause
    exit /b 1
)
if %major% EQU 3 if %minor% LSS 10 (
    echo [ERRORE] Richiesto Python 3.10 o superiore. Trovata versione %pyver%
    pause
    exit /b 1
)

echo [OK] Python %pyver% rilevato.

REM 2. Creazione Ambiente Virtuale
if not exist venv (
    echo [INFO] Creazione ambiente virtuale (venv)...
    python -m venv venv
) else (
    echo [INFO] venv gia' esistente.
)

REM 3. Installazione dipendenze
echo [INFO] Attivazione venv e installazione dipendenze...
call venv\Scripts\activate
pip install --upgrade pip
pip install -r requirements.txt

REM 4. Playwright Setup
echo [INFO] Installazione Playwright Chromium...
playwright install chromium

REM 5. Configurazione Task Scheduler
echo [INFO] Configurazione Task Scheduler (09:00 ogni giorno)...
set PROJECT_DIR=%~dp0
set RUN_BAT=%PROJECT_DIR%run_agent.bat

REM Creiamo il file run_agent.bat se non esiste o lo aggiorniamo per usare il venv
(
echo @echo off
echo cd /d "%PROJECT_DIR%"
echo call venv\Scripts\activate
echo python src/agent.py
echo start "" "reports/report_bandi.html"
) > run_agent.bat

schtasks /create /tn "BandiRadarDaily" /tr "\"%RUN_BAT%\"" /sc daily /st 09:00 /f

echo.
echo ################################################
echo #   INSTALLAZIONE COMPLETATA!                #
echo ################################################
echo.
echo Per avviare subito la ricerca, esegui run_agent.bat
echo Il report sara' in reports/report_bandi.html
echo.
pause
