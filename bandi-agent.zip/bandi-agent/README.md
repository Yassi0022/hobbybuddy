# BandiRadar Sicilia 🔍
Un agente intelligente per scovare opportunità, selezionarle in base al tuo profilo e riassumerle automaticamente con l'IA.

## Cosa fa
- **Scraping Intelligente**: Monitora decine di fonti (InPA, Comune di Palermo, GURS, portali appalti) e visita ogni bando per leggerne il contenuto.
- **Analisi IA**: Usa Ollama (LLM locale) per valutare quanto un bando sia rilevante per te.
- **Report Professionale**: Genera un dashboard HTML moderno con filtri live, dark mode e riassunti automatici.
- **Automazione**: Si installa come attività pianificata per girare ogni mattina alle 09:00.

## Requisiti
- **Python 3.10+**
- **Ollama** installato e in esecuzione (modello `qwen2.5-coder:latest` consigliato).
- **Connessione Internet** per lo scraping.

## Installazione (3 step)
1. **Ollama**: Assicurati di aver scaricato e avviato Ollama. Esegui `ollama pull qwen2.5-coder:latest`.
2. **Installazione**: Fai doppio clic su `install.bat`. Creerà automaticamente un ambiente virtuale (`venv`), installerà le dipendenze e configurerà l'agente.
3. **Task Scheduler**: `install.bat` configurerà l'agente per l'esecuzione automatica quotidiana.

## Come si usa
- **Esecuzione Manuale**: Avvia `run_agent.bat` per aggiornare subito i bandi.
- **Visualizzazione**: Apri `reports/report_bandi.html` per vedere i risultati.
- **Aggiornamento**: L'agente scarica solo i nuovi bandi, mantenendo lo storico degli ultimi 3 giorni.

## Personalizzazione
### Aggiungere nuove fonti
Modifica `src/config.py` e aggiungi la URL alla lista `SOURCES`. Se il sito richiede JavaScript (es. portali dinamici), aggiungilo anche a `js_sources` in `src/agent.py`.

### Profilo Utente
Il sistema analizza i bandi in base a chi sei. Puoi cambiare il tuo profilo in `src/config.py` modificando la variabile `PROFILO_UTENTE`. Attualmente è impostato per:
> *Psicologo del Lavoro e Ingegnere Informatico residente a Palermo.*

## Struttura File
- `src/agent.py`: Il cuore dell'agente.
- `src/scraper.py`: Logica di raccolta dati.
- `src/analyzer.py`: Integrazione con Ollama.
- `src/reporter.py`: Generatore del report HTML.
- `db/bandi.db`: Database SQLite (creato automaticamente).
- `reports/`: Contiene il report generato.

## Troubleshooting
- **Ollama Error**: Se vedi errori relativi all'IA, assicurati che Ollama sia aperto e raggiungibile su `localhost:11434`.
- **Playwright Error**: Se lo scraping fallisce sui siti dinamici, esegui `venv\Scripts\playwright install chromium` nel terminale.

---
*Sviluppato per automazione professionale. Buona caccia ai bandi!*