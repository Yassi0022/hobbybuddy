import sqlite3
import os

# Configurazione del percorso del database
DB_PATH = os.path.join('db', 'bandi.db')

# Connessione al database
conn = sqlite3.connect(DB_PATH)
cursor = conn.cursor()

# Conta il numero di bandi nel database
try:
    cursor.execute('SELECT COUNT(*) FROM bandi')
    count = cursor.fetchone()[0]

    print(f"Numero di bandi nel database: {count}")

    # Se ci sono bandi, mostra i primi 5
    if count > 0:
        cursor.execute('SELECT * FROM bandi LIMIT 5')
        bandi = cursor.fetchall()

        print("\nPrimi 5 bandi:")
        for bando in bandi:
            print(bando)
    else:
        print("Nessun bando trovato nel database.")

except sqlite3.Error as e:
    print(f"Errore nell'accesso al database: {e}")
finally:
    conn.close()